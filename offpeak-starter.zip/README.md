# OffPeak — student pretotype
A static, mobile-friendly concept for discounted spare sports and fitness capacity. All listings are hypothetical. No payments, real bookings, analytics or data collection are implemented.

## Run locally
Open `index.html` in a browser. No installation or dependencies required.

## Publish
Upload these four files to the root of a shared GitHub repository. In Settings > Pages choose Deploy from a branch, main, / (root), then Save. Free GitHub Pages hosting generally requires a public repository.

## Edit together
Invite your partner through Settings > Collaborators. Make separate branches for substantial changes; review pull requests before merging into main. Keep private research data out of the repository.

## Research setup
Create customer and coach Google Forms with a consent notice. Paste their published responder URLs into `customerForm` and `coachForm` in script.js. Ask customers which example session and price they selected; the generic form links do not automatically pass session details. Test both links before sharing. Form submissions can measure expressed interest, not actual purchases. Visitor and click analytics are not installed. Add only consent-appropriate analytics if needed.

## Files
- index.html: structure and copy
- style.css: visual design and responsive layout
- script.js: sample listings, filters and interest dialog
