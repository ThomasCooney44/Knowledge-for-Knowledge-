// Replace these illustrative listings with verified pilot offers when available.
const sessions = [
 {name:'Tennis lesson',category:'Tennis',icon:'🎾',location:'South Dublin',duration:60,price:25,original:40},
 {name:'Golf coaching',category:'Golf',icon:'⛳',location:'North Dublin',duration:45,price:30,original:50},
 {name:'Personal training',category:'Fitness',icon:'🏋️',location:'Dublin city centre',duration:60,price:30,original:50},
 {name:'Reformer Pilates',category:'Pilates',icon:'🧘',location:'Dublin city centre',duration:50,price:12,original:24}
];
// Paste your published Google Forms responder links here (not edit links).
const customerForm = '';
const coachForm = '';
const filters = document.querySelector('#filters');
const cards = document.querySelector('#cards');
const dialog = document.querySelector('#interest');
let selected = 'All';
function render(){
 filters.replaceChildren();
 for(const category of ['All',...new Set(sessions.map(s=>s.category))]){
  const button=document.createElement('button');button.textContent=category;button.setAttribute('aria-pressed',String(selected===category));button.onclick=()=>{selected=category;render();[...filters.children].find(b=>b.textContent===category)?.focus()};filters.append(button);
 }
 const visible=sessions.filter(s=>selected==='All'||s.category===selected);
 document.querySelector('#count').textContent=`${visible.length} sample sessions`;
 cards.replaceChildren();
 for(const s of visible){
  const article=document.createElement('article');article.className='card';
  article.innerHTML=`<div class="visual" aria-hidden="true">${s.icon}</div><div class="details"><span class="discount">${Math.round((1-s.price/s.original)*100)}% OFF · SAMPLE</span><h3>${s.name}</h3><p>${s.location} · ${s.duration} minutes</p><div class="price">€${s.price}<s>€${s.original}</s></div><button class="button">I'm interested</button></div>`;
  article.querySelector('button').onclick=()=>openInterest(s);cards.append(article);
 }
}
function openInterest(session){
 const url=session?customerForm:coachForm;
 document.querySelector('#dialog-title').textContent=session?`Interested in ${session.name.toLowerCase()}?`:'Interested in becoming a partner?';
 document.querySelector('#dialog-copy').textContent=session?`This €${session.price} session is an illustrative offer. We are testing interest before launching; no booking or payment is being made.`:'We are researching whether coaches would offer spare capacity through a discounted marketplace.';
 const link=document.querySelector('#form-link');link.hidden=!url;if(url)link.href=url;else link.removeAttribute('href');
 document.querySelector('#demo-note').hidden=Boolean(url);dialog.showModal();
}
document.querySelector('#partner').onclick=()=>openInterest(null);render();
